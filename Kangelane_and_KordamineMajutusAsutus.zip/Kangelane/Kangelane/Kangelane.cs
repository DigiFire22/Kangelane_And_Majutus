﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kangelased
{
    //1. loo klass
    public class Kangelane
    {
        //2. loo väljad
        private string _Nimi;
        private string _Asukoht;

        //3. loo konstruktor

        public Kangelane(string nimi, string asukoht)
        {
            //4. väärtusta väljad
            _Nimi = nimi;
            _Asukoht = asukoht;
        }
        public string Nimi { get => _Nimi; set => _Nimi = value; }
        public string Asukoht { get => _Asukoht; set => _Asukoht = value; }

        //5. tee midagi kasuliku

        public virtual int Päästa(int ohus_olendid)
        {
            return Convert.ToInt32(ohus_olendid * 0.95);
        }
        public override string ToString()
        {
            return $"{_Nimi} kaitseb {_Asukoht}";
        }
    }


}
