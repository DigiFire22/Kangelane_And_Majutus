﻿using System;
using System.Collections.Generic;
using System.IO;

namespace Kangelased
{
    class Programm
    {
        private static List<Kangelane> kangelased = new();
        private static void LaeKangelased(string failiNimi)
        {
            var failiRead = File.ReadAllLines(failiNimi);
            foreach(var rida in failiRead)
            {
                var kaldkriips = rida.IndexOf("/");
                var nimi = rida.Substring(0, kaldkriips - 1);
                var asukoht = rida.Substring(kaldkriips + 2);
                if (nimi.EndsWith("*"))
                {
                    kangelased.Add(new SuperKangelane(nimi.Substring(0, nimi.Length - 1), asukoht));
                }
                else
                {
                    kangelased.Add(new Kangelane(nimi, asukoht));
                }
            }
        }
        static void Main(string[] args)
        {
            Kangelane kangelane = new Kangelane("batman", "Gotham");
            Console.WriteLine("Mitu Inimest on ohus: ");
            SuperKangelane superKangelane= new SuperKangelane("Superman", "Metropolis");
            int ohusohus_olendid = int.Parse(Console.ReadLine());
            Console.WriteLine(superKangelane);
            LaeKangelased("Kangelased.txt");
            foreach (var hero in kangelased)
            {
                Console.WriteLine(hero + "\nPäästis 1000/" + hero.Päästa());
            }
        }
    }
}
