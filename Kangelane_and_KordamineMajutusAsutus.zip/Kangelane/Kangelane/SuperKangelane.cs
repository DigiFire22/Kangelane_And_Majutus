﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kangelased
{
    public class SuperKangelane : Kangelane
    {
        private static Random random = new Random();
        private double _osavus;
        public SuperKangelane(string nimi, string asukoht):base(nimi, asukoht)
        {
            _osavus = random.NextDouble() + random.Next(1, 5);
        }
        public override int Päästa(int ohus_olendid)
        {
            return Convert.ToInt32(ohus_olendid * (95 + _osavus) / 100);
        }
        public override string ToString()
        {
            return base.ToString() + $"\nLisaks on ta {_osavus}% osavam kui tavakangelane";
        }
    }
}
