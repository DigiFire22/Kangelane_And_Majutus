﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KordamineMajutusAsutus
{
    class MajutusAsutus
    {
        private decimal _hind;
        private int _kohti;
        private int _vabuKohti;

        public MajutusAsutus(decimal hind, int kohti)
        {
            _hind = hind;
            _kohti = kohti;
            _vabuKohti = kohti;
        }


        public int vabukohti
        {
            get { return _vabuKohti; }
            set { _vabuKohti = value; }
        }

    }
}
